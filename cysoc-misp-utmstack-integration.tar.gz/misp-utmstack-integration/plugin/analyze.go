package main

import (
	"fmt"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"github.com/google/uuid"
	"github.com/threatwinds/go-sdk/catcher"
	"github.com/threatwinds/go-sdk/plugins"
	"google.golang.org/protobuf/proto"
	"google.golang.org/protobuf/types/known/structpb"
)

// Match describes where in an event an indicator was found.
type Match struct {
	Ind      *Indicator
	Observed string // the value seen in the event
	Field    string // e.g. target.ip, origin.domain, log.dstHost
	Kind     string // ip | domain | url | hash | email
	OnTarget bool   // true when the malicious value is on the target side
}

var matchCount atomic.Uint64

// analyze is called by the EventProcessor for every parsed event. It must be
// fast: plain map lookups, no I/O. On a hit it streams one alert back.
func analyze(event *plugins.Event, srv plugins.Analysis_AnalyzeServer) error {
	defer func() {
		if r := recover(); r != nil {
			_ = catcher.Error("recovered from panic in analyze", nil, map[string]any{"process": processName, "panic": r})
		}
	}()

	s := settings()
	if !wantDataType(s, event.GetDataType()) {
		return nil
	}

	m := findMatch(db.Load(), s, event)
	if m == nil {
		return nil
	}

	severity := m.Ind.ThreatLevel
	if severity == "" {
		severity = s.DefaultSeverity
	}
	if severityRank(severity) < severityRank(s.MinSeverity) {
		return nil
	}

	other := event.GetTarget().GetIp()
	if m.OnTarget {
		other = event.GetOrigin().GetIp()
	}
	if suppressed(m.Ind.Value+"|"+other, time.Duration(s.SuppressMinutes)*time.Minute) {
		return nil
	}

	matchCount.Add(1)
	alert := buildAlert(event, m, severity, s)
	if err := srv.Send(alert); err != nil {
		return catcher.Error("cannot send alert to the EventProcessor", err, map[string]any{"process": processName})
	}
	return nil
}

func wantDataType(s *Settings, dt string) bool {
	if _, excluded := s.ExcludeTypes[dt]; excluded {
		return false
	}
	if len(s.DataTypes) == 0 {
		return true
	}
	_, ok := s.DataTypes[dt]
	return ok
}

// findMatch checks the standard origin/target fields first, then any extra
// log.* fields configured by the SOC.
func findMatch(d *DB, s *Settings, e *plugins.Event) *Match {
	if d == nil || d.Size() == 0 {
		return nil
	}
	sides := []struct {
		name     string
		side     *plugins.Side
		onTarget bool
	}{
		// target first: outbound traffic to a bad IP/domain is the most common hit
		{"target", e.GetTarget(), true},
		{"origin", e.GetOrigin(), false},
	}
	for _, sd := range sides {
		if sd.side == nil {
			continue
		}
		if m := matchSide(d, s, sd.side, sd.name); m != nil {
			m.OnTarget = sd.onTarget
			return m
		}
	}

	for _, f := range s.ExtraFields {
		v := logValue(e, f)
		if v == "" {
			continue
		}
		if ind, kind := d.LookupAny(v, s.MatchSubdomains); ind != nil {
			return &Match{Ind: ind, Observed: v, Field: f, Kind: kind}
		}
	}
	return nil
}

func matchSide(d *DB, s *Settings, sd *plugins.Side, prefix string) *Match {
	try := func(field, val, kind string, ind *Indicator) *Match {
		if ind == nil {
			return nil
		}
		return &Match{Ind: ind, Observed: val, Field: prefix + "." + field, Kind: kind}
	}
	if v := sd.GetIp(); v != "" {
		if m := try("ip", v, "ip", d.LookupIP(v)); m != nil {
			return m
		}
	}
	for _, f := range []struct{ name, val string }{{"domain", sd.GetDomain()}, {"host", sd.GetHost()}} {
		if f.val != "" {
			if m := try(f.name, f.val, "domain", d.LookupDomain(f.val, s.MatchSubdomains)); m != nil {
				return m
			}
		}
	}
	if v := sd.GetUrl(); v != "" {
		if m := try("url", v, "url", d.LookupURL(v)); m != nil {
			return m
		}
		// a URL IOC may be missing but its host may be listed as a domain
		if h := hostOf(v); h != "" {
			if m := try("url", v, "domain", d.LookupDomain(h, s.MatchSubdomains)); m != nil {
				return m
			}
		}
	}
	for _, f := range []struct{ name, val string }{
		{"sha256", sd.GetSha256()}, {"sha1", sd.GetSha1()}, {"md5", sd.GetMd5()},
		{"sha512", sd.GetSha512()}, {"hash", sd.GetHash()},
	} {
		if f.val != "" {
			if m := try(f.name, f.val, "hash", d.LookupHash(f.val)); m != nil {
				return m
			}
		}
	}
	for _, f := range []struct{ name, val string }{{"email", sd.GetEmail()}, {"emailAddress", sd.GetEmailAddress()}} {
		if f.val != "" {
			if m := try(f.name, f.val, "email", d.LookupEmail(f.val)); m != nil {
				return m
			}
		}
	}
	return nil
}

func hostOf(raw string) string {
	k := normURL(raw)
	if k == "" {
		return ""
	}
	h := k
	if i := strings.IndexAny(h, "/?"); i >= 0 {
		h = h[:i]
	}
	if i := strings.LastIndexByte(h, ':'); i >= 0 && !strings.Contains(h[:i], ":") {
		h = h[:i]
	}
	return h
}

// logValue reads a dotted path such as "log.dstHost" or "log.dns.query" from
// the event's free-form log map.
func logValue(e *plugins.Event, path string) string {
	path = strings.TrimPrefix(path, "log.")
	parts := strings.Split(path, ".")
	m := e.GetLog()
	if m == nil {
		return ""
	}
	v, ok := m[parts[0]]
	for _, p := range parts[1:] {
		if !ok || v == nil {
			return ""
		}
		st := v.GetStructValue()
		if st == nil {
			return ""
		}
		v, ok = st.GetFields()[p]
	}
	if !ok || v == nil {
		return ""
	}
	return v.GetStringValue()
}

// ---- alert construction ----

func buildAlert(event *plugins.Event, m *Match, severity string, s *Settings) *plugins.Alert {
	ev := proto.Clone(event).(*plugins.Event)
	if ev.Log == nil {
		ev.Log = map[string]*structpb.Value{}
	}
	ev.Log["mispIndicator"] = structpb.NewStringValue(m.Ind.Value)
	ev.Log["mispObserved"] = structpb.NewStringValue(m.Observed)
	ev.Log["mispIndicatorType"] = structpb.NewStringValue(m.Ind.Type)
	ev.Log["mispCategory"] = structpb.NewStringValue(m.Ind.Category)
	ev.Log["mispEventId"] = structpb.NewStringValue(m.Ind.EventID)
	ev.Log["mispEventInfo"] = structpb.NewStringValue(m.Ind.EventInfo)
	ev.Log["mispMatchedField"] = structpb.NewStringValue(m.Field)
	ev.Log["mispThreatLevel"] = structpb.NewStringValue(severity)
	if len(m.Ind.Tags) > 0 {
		ev.Log["mispTags"] = structpb.NewStringValue(strings.Join(m.Ind.Tags, ", "))
	}

	adversary, target := ev.GetOrigin(), ev.GetTarget()
	if m.OnTarget {
		adversary, target = target, adversary
	}

	lvl := uint32(severityRank(severity))
	impact := &plugins.Impact{Confidentiality: lvl, Integrity: lvl, Availability: 0}

	var refs []string
	if s.URL != "" && m.Ind.EventID != "" {
		refs = append(refs, fmt.Sprintf("%s/events/view/%s", s.URL, m.Ind.EventID))
	}

	a := &plugins.Alert{
		Id:          uuid.NewString(),
		Timestamp:   time.Now().UTC().Format(time.RFC3339Nano),
		Name:        "MISP Threat Intelligence Match: " + kindLabel(m.Kind),
		TenantId:    ev.GetTenantId(),
		TenantName:  ev.GetTenantName(),
		DataSource:  ev.GetDataSource(),
		DataType:    ev.GetDataType(),
		Category:    "Threat Intelligence",
		Technique:   "",
		Description: describe(m, severity),
		References:  refs,
		Impact:      impact,
		ImpactScore: lvl,
		Severity:    severity,
		Adversary:   adversary,
		Target:      target,
		Events:      []*plugins.Event{ev},
	}

	keys := []string{"lastEvent.log.mispIndicator"}
	if ip := target.GetIp(); ip != "" {
		keys = append(keys, "target.ip")
	}
	switch s.AlertMode {
	case "group":
		a.GroupBy = keys
	case "deduplicate":
		a.DeduplicateBy = keys
	}
	return a
}

func kindLabel(k string) string {
	switch k {
	case "ip":
		return "Malicious IP"
	case "domain":
		return "Malicious Domain"
	case "url":
		return "Malicious URL"
	case "hash":
		return "Malicious File Hash"
	case "email":
		return "Malicious Email Address"
	}
	return "Indicator"
}

func describe(m *Match, severity string) string {
	var b strings.Builder
	fmt.Fprintf(&b, "The value %q seen in %s matches a MISP indicator (%s: %s).",
		m.Observed, m.Field, m.Ind.Type, m.Ind.Value)
	if m.Ind.EventID != "" {
		fmt.Fprintf(&b, " MISP event #%s: %s.", m.Ind.EventID, m.Ind.EventInfo)
	}
	if m.Ind.Category != "" {
		fmt.Fprintf(&b, " Category: %s.", m.Ind.Category)
	}
	fmt.Fprintf(&b, " Threat level: %s.", severity)
	if len(m.Ind.Tags) > 0 {
		fmt.Fprintf(&b, " Tags: %s.", strings.Join(m.Ind.Tags, ", "))
	}
	if m.Ind.Comment != "" {
		fmt.Fprintf(&b, " Analyst comment: %s.", m.Ind.Comment)
	}
	b.WriteString(" Investigate the internal host, confirm whether the connection succeeded, and block the indicator if it is confirmed malicious.")
	return b.String()
}

// ---- in-memory suppression so one noisy indicator cannot flood the console ----

var (
	suppressMu sync.Mutex
	lastSeen   = map[string]time.Time{}
)

func suppressed(key string, window time.Duration) bool {
	if window <= 0 {
		return false
	}
	now := time.Now()
	suppressMu.Lock()
	defer suppressMu.Unlock()
	if t, ok := lastSeen[key]; ok && now.Sub(t) < window {
		return true
	}
	lastSeen[key] = now
	return false
}

func pruneSuppression(window time.Duration) {
	cutoff := time.Now().Add(-window)
	suppressMu.Lock()
	defer suppressMu.Unlock()
	for k, t := range lastSeen {
		if t.Before(cutoff) {
			delete(lastSeen, k)
		}
	}
}
