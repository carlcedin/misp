package main

import (
	"strings"
	"sync/atomic"

	"github.com/threatwinds/go-sdk/plugins"
	"github.com/tidwall/gjson"
)

// PluginName is the name the UTMStack EventProcessor uses to find this plugin.
// It must match:
//   - the binary name:  com.utmstack.misp.plugin
//   - the socket name:  {{WorkDir}}/sockets/com.utmstack.misp_analysis.sock
//   - the entry added to plugins.analysis.order
//   - the key under "plugins:" in the pipeline config file
const PluginName = "com.utmstack.misp"

const processName = "plugin_" + PluginName

// Settings holds the plugin configuration read from
// /workdir/pipeline/*.yaml -> plugins: com.utmstack.misp: {...}
type Settings struct {
	URL                string
	APIKey             string
	InsecureSkipVerify bool
	CACertFile         string

	RefreshMinutes     int
	Lookback           string
	OnlyToIDS          bool
	PublishedOnly      bool
	EnforceWarninglist bool
	Types              []string
	Tags               []string
	PageSize           int
	MaxPages           int
	TimeoutSeconds     int

	UseThreatLevel  bool
	DefaultSeverity string
	MinSeverity     string

	MatchSubdomains bool
	ExtraFields     []string
	Allowlist       map[string]struct{}
	DataTypes       map[string]struct{}
	ExcludeTypes    map[string]struct{}

	AlertMode       string // group | deduplicate | none
	SuppressMinutes int

	CacheFile string
}

// DefaultTypes are the MISP attribute types pulled when "types" is not configured.
var DefaultTypes = []string{
	"ip-src", "ip-dst", "ip-src|port", "ip-dst|port", "domain|ip",
	"domain", "hostname", "hostname|port",
	"url",
	"md5", "sha1", "sha256", "sha512",
	"filename|md5", "filename|sha1", "filename|sha256", "filename|sha512",
	"email", "email-src", "email-dst",
}

var current atomic.Pointer[Settings]

func settings() *Settings {
	s := current.Load()
	if s == nil {
		return defaults()
	}
	return s
}

func defaults() *Settings {
	return &Settings{
		RefreshMinutes:     15,
		Lookback:           "90d",
		OnlyToIDS:          true,
		PublishedOnly:      true,
		EnforceWarninglist: true,
		Types:              DefaultTypes,
		PageSize:           5000,
		MaxPages:           200,
		TimeoutSeconds:     120,
		UseThreatLevel:     true,
		DefaultSeverity:    "medium",
		MinSeverity:        "low",
		MatchSubdomains:    true,
		Allowlist:          map[string]struct{}{},
		DataTypes:          map[string]struct{}{},
		ExcludeTypes:       map[string]struct{}{},
		AlertMode:          "group",
		SuppressMinutes:    60,
		CacheFile:          "/workdir/logs/com.utmstack.misp.cache.json",
	}
}

// loadSettings reads the current plugin configuration. The go-sdk reloads the
// pipeline folder automatically, so edits to the YAML file are picked up on the
// next refresh cycle without restarting anything.
func loadSettings() *Settings {
	return parseSettings(plugins.PluginCfg(PluginName))
}

func parseSettings(cfg gjson.Result) *Settings {
	s := defaults()
	if !cfg.Exists() {
		return s
	}

	s.URL = strings.TrimRight(strings.TrimSpace(cfg.Get("url").String()), "/")
	s.APIKey = strings.TrimSpace(cfg.Get("apiKey").String())
	s.InsecureSkipVerify = cfg.Get("insecureSkipVerify").Bool()
	s.CACertFile = cfg.Get("caCertFile").String()

	setInt(cfg, "refreshMinutes", &s.RefreshMinutes, 1)
	setInt(cfg, "pageSize", &s.PageSize, 100)
	setInt(cfg, "maxPages", &s.MaxPages, 1)
	setInt(cfg, "timeoutSeconds", &s.TimeoutSeconds, 10)
	setInt(cfg, "suppressMinutes", &s.SuppressMinutes, 0)

	if v := cfg.Get("lookback"); v.Exists() {
		s.Lookback = v.String()
	}
	setBool(cfg, "onlyToIds", &s.OnlyToIDS)
	setBool(cfg, "publishedOnly", &s.PublishedOnly)
	setBool(cfg, "enforceWarninglist", &s.EnforceWarninglist)
	setBool(cfg, "useThreatLevel", &s.UseThreatLevel)
	setBool(cfg, "matchSubdomains", &s.MatchSubdomains)

	if t := strList(cfg.Get("types")); len(t) > 0 {
		s.Types = t
	}
	s.Tags = strList(cfg.Get("tags"))
	s.ExtraFields = strList(cfg.Get("extraFields"))

	if v := normSeverity(cfg.Get("defaultSeverity").String()); v != "" {
		s.DefaultSeverity = v
	}
	if v := normSeverity(cfg.Get("minSeverity").String()); v != "" {
		s.MinSeverity = v
	}

	for _, v := range strList(cfg.Get("allowlist")) {
		s.Allowlist[strings.ToLower(v)] = struct{}{}
	}
	for _, v := range strList(cfg.Get("dataTypes")) {
		s.DataTypes[v] = struct{}{}
	}
	for _, v := range strList(cfg.Get("excludeDataTypes")) {
		s.ExcludeTypes[v] = struct{}{}
	}

	switch m := strings.ToLower(cfg.Get("alertMode").String()); m {
	case "group", "deduplicate", "none":
		s.AlertMode = m
	}
	if v := cfg.Get("cacheFile"); v.Exists() {
		s.CacheFile = v.String()
	}
	return s
}

func setInt(cfg gjson.Result, key string, dst *int, min int) {
	if v := cfg.Get(key); v.Exists() {
		n := int(v.Int())
		if n >= min {
			*dst = n
		}
	}
}

func setBool(cfg gjson.Result, key string, dst *bool) {
	if v := cfg.Get(key); v.Exists() {
		*dst = v.Bool()
	}
}

func strList(v gjson.Result) []string {
	var out []string
	for _, e := range v.Array() {
		if s := strings.TrimSpace(e.String()); s != "" {
			out = append(out, s)
		}
	}
	return out
}

func normSeverity(s string) string {
	switch strings.ToLower(strings.TrimSpace(s)) {
	case "low":
		return "low"
	case "medium":
		return "medium"
	case "high":
		return "high"
	}
	return ""
}

func severityRank(s string) int {
	switch s {
	case "high":
		return 3
	case "medium":
		return 2
	case "low":
		return 1
	}
	return 0
}
