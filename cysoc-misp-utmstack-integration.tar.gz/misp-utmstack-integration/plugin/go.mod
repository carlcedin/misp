module github.com/cysoc/utmstack-misp-plugin

go 1.25.5

require (
	github.com/google/uuid v1.6.0
	github.com/threatwinds/go-sdk v1.1.34
	github.com/tidwall/gjson v1.19.0
	google.golang.org/protobuf v1.36.11
)
