package main

import (
	"net"
	"net/url"
	"strings"
	"sync/atomic"
)

// Indicator is one MISP attribute, reduced to what an alert needs.
type Indicator struct {
	Value       string   `json:"value"`
	Type        string   `json:"type"`
	Category    string   `json:"category"`
	Comment     string   `json:"comment,omitempty"`
	EventID     string   `json:"eventId"`
	EventInfo   string   `json:"eventInfo"`
	ThreatLevel string   `json:"threatLevel"` // high | medium | low | "" (undefined)
	Tags        []string `json:"tags,omitempty"`
}

// cidrIndicator holds network-range indicators (e.g. ip-dst 203.0.113.0/24).
type cidrIndicator struct {
	Net *net.IPNet
	Ind *Indicator
}

// DB is an immutable snapshot of all indicators; refreshes swap it atomically so
// lookups on the hot path never block.
type DB struct {
	IPs     map[string]*Indicator
	CIDRs   []cidrIndicator
	Domains map[string]*Indicator
	URLs    map[string]*Indicator
	Hashes  map[string]*Indicator
	Emails  map[string]*Indicator
}

func newDB() *DB {
	return &DB{
		IPs:     map[string]*Indicator{},
		Domains: map[string]*Indicator{},
		URLs:    map[string]*Indicator{},
		Hashes:  map[string]*Indicator{},
		Emails:  map[string]*Indicator{},
	}
}

func (d *DB) Size() int {
	return len(d.IPs) + len(d.CIDRs) + len(d.Domains) + len(d.URLs) + len(d.Hashes) + len(d.Emails)
}

func (d *DB) Counts() map[string]any {
	return map[string]any{
		"ips": len(d.IPs), "cidrs": len(d.CIDRs), "domains": len(d.Domains),
		"urls": len(d.URLs), "hashes": len(d.Hashes), "emails": len(d.Emails),
	}
}

var db atomic.Pointer[DB]

func init() { db.Store(newDB()) }

// Add files a MISP attribute into the right lookup table(s), splitting
// composite types such as "domain|ip" and "filename|sha256".
func (d *DB) Add(ind *Indicator) {
	t := strings.ToLower(ind.Type)
	v := strings.TrimSpace(ind.Value)
	first, second, composite := strings.Cut(v, "|")

	switch t {
	case "ip-src", "ip-dst":
		d.addIP(v, ind)
	case "ip-src|port", "ip-dst|port":
		d.addIP(first, ind)
	case "domain|ip":
		d.addDomain(first, ind)
		if composite {
			d.addIP(second, ind)
		}
	case "domain", "hostname":
		d.addDomain(v, ind)
	case "hostname|port":
		d.addDomain(first, ind)
	case "url", "uri", "link":
		if k := normURL(v); k != "" {
			d.URLs[k] = ind
		}
	case "md5", "sha1", "sha224", "sha256", "sha384", "sha512", "ssdeep", "imphash", "authentihash", "tlsh":
		d.addHash(v, ind)
	case "filename|md5", "filename|sha1", "filename|sha256", "filename|sha512", "filename|imphash", "filename|authentihash":
		if composite {
			d.addHash(second, ind)
		}
	case "email", "email-src", "email-dst":
		if v != "" {
			d.Emails[strings.ToLower(v)] = ind
		}
	}
}

func (d *DB) addIP(v string, ind *Indicator) {
	v = strings.TrimSpace(v)
	if strings.Contains(v, "/") {
		if _, n, err := net.ParseCIDR(v); err == nil {
			ones, bits := n.Mask.Size()
			if ones == bits { // a /32 or /128 is a single address
				d.IPs[n.IP.String()] = ind
				return
			}
			d.CIDRs = append(d.CIDRs, cidrIndicator{Net: n, Ind: ind})
		}
		return
	}
	if ip := net.ParseIP(v); ip != nil {
		d.IPs[ip.String()] = ind
	}
}

func (d *DB) addDomain(v string, ind *Indicator) {
	if k := normDomain(v); k != "" {
		d.Domains[k] = ind
	}
}

func (d *DB) addHash(v string, ind *Indicator) {
	if v = strings.ToLower(strings.TrimSpace(v)); v != "" {
		d.Hashes[v] = ind
	}
}

// ---- lookups (hot path) ----

func (d *DB) LookupIP(v string) *Indicator {
	ip := net.ParseIP(strings.TrimSpace(v))
	if ip == nil {
		return nil
	}
	if ind, ok := d.IPs[ip.String()]; ok {
		return ind
	}
	for _, c := range d.CIDRs {
		if c.Net.Contains(ip) {
			return c.Ind
		}
	}
	return nil
}

func (d *DB) LookupDomain(v string, subdomains bool) *Indicator {
	k := normDomain(v)
	if k == "" {
		return nil
	}
	if ind, ok := d.Domains[k]; ok {
		return ind
	}
	if !subdomains {
		return nil
	}
	// a.b.evil.com -> b.evil.com -> evil.com (never a bare TLD)
	for {
		i := strings.IndexByte(k, '.')
		if i < 0 {
			return nil
		}
		k = k[i+1:]
		if !strings.Contains(k, ".") {
			return nil
		}
		if ind, ok := d.Domains[k]; ok {
			return ind
		}
	}
}

func (d *DB) LookupURL(v string) *Indicator {
	if k := normURL(v); k != "" {
		return d.URLs[k]
	}
	return nil
}

func (d *DB) LookupHash(v string) *Indicator {
	if v = strings.ToLower(strings.TrimSpace(v)); v != "" {
		return d.Hashes[v]
	}
	return nil
}

func (d *DB) LookupEmail(v string) *Indicator {
	if v = strings.ToLower(strings.TrimSpace(v)); v != "" {
		return d.Emails[v]
	}
	return nil
}

// LookupAny tries every table; used for free-form log.* fields.
func (d *DB) LookupAny(v string, subdomains bool) (*Indicator, string) {
	if ind := d.LookupIP(v); ind != nil {
		return ind, "ip"
	}
	if ind := d.LookupHash(v); ind != nil {
		return ind, "hash"
	}
	if ind := d.LookupEmail(v); ind != nil {
		return ind, "email"
	}
	if strings.Contains(v, "://") {
		if ind := d.LookupURL(v); ind != nil {
			return ind, "url"
		}
		return nil, ""
	}
	if ind := d.LookupDomain(v, subdomains); ind != nil {
		return ind, "domain"
	}
	return nil, ""
}

// ---- normalisation ----

func normDomain(v string) string {
	v = strings.ToLower(strings.TrimSpace(v))
	v = strings.TrimSuffix(v, ".")
	if v == "" || strings.ContainsAny(v, "/ @") || !strings.Contains(v, ".") {
		return ""
	}
	if net.ParseIP(v) != nil {
		return ""
	}
	return v
}

// normURL lowercases scheme and host, drops default ports, fragments and a
// trailing slash so "HTTP://Evil.com/x/" and "http://evil.com/x" match.
func normURL(v string) string {
	v = strings.TrimSpace(v)
	if v == "" {
		return ""
	}
	if !strings.Contains(v, "://") {
		v = "http://" + v
	}
	u, err := url.Parse(v)
	if err != nil || u.Host == "" {
		return ""
	}
	host := strings.ToLower(u.Hostname())
	port := u.Port()
	scheme := strings.ToLower(u.Scheme)
	if (scheme == "http" && port == "80") || (scheme == "https" && port == "443") {
		port = ""
	}
	if port != "" {
		host += ":" + port
	}
	path := strings.TrimSuffix(u.EscapedPath(), "/")
	out := host + path
	if u.RawQuery != "" {
		out += "?" + u.RawQuery
	}
	return out // scheme deliberately ignored: http vs https of the same IOC is the same IOC
}
