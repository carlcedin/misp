//go:build integration

// End-to-end test that exercises the plugin the way the UTMStack
// EventProcessor does: config from YAML files in $WORK_DIR/pipeline, a gRPC
// Analyze call over the unix socket, and alerts streamed back.
//
// Run with:  WORK_DIR=$(mktemp -d) go test -tags integration -run Integration -v .
package main

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"testing"
	"time"

	"github.com/threatwinds/go-sdk/plugins"
	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials/insecure"
)

func TestIntegrationEndToEnd(t *testing.T) {
	wd := os.Getenv("WORK_DIR")
	if wd == "" || plugins.WorkDir != wd {
		t.Skip("set WORK_DIR to a temp dir")
	}

	misp := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/attributes/restSearch":
			var q map[string]any
			_ = json.NewDecoder(r.Body).Decode(&q)
			var attrs []any
			if q["page"].(float64) == 1 {
				attrs = []any{map[string]any{"type": "ip-dst", "value": "203.0.113.10", "event_id": "42",
					"category": "Network activity", "Event": map[string]any{"info": "APT C2"}}}
			}
			_ = json.NewEncoder(w).Encode(map[string]any{"response": map[string]any{"Attribute": attrs}})
		case "/events/index":
			_, _ = io.WriteString(w, `[{"id":"42","threat_level_id":"1"}]`)
		}
	}))
	defer misp.Close()

	pipe := filepath.Join(wd, "pipeline")
	_ = os.MkdirAll(pipe, 0o755)
	// what UTMStack's installer writes
	write(t, filepath.Join(pipe, "system_plugins_analysis.yaml"),
		"plugins:\n  analysis:\n    order:\n    - com.utmstack.events\n    - cel\n    - feeds\n")
	// what install.sh writes
	write(t, filepath.Join(pipe, "zz_cysoc_misp_analysis_order.yaml"),
		"plugins:\n  analysis:\n    order:\n    - com.utmstack.events\n    - cel\n    - feeds\n    - com.utmstack.misp\n")
	write(t, filepath.Join(pipe, "cysoc_misp.yaml"), fmt.Sprintf(
		"plugins:\n  com.utmstack.misp:\n    url: %s\n    apiKey: secret\n    refreshMinutes: 15\n    cacheFile: %s\n",
		misp.URL, filepath.Join(wd, "logs", "cache.json")))

	// 1. config merge: our override must win and our settings must load
	order := plugins.PluginCfg("analysis").Get("order").Array()
	if len(order) != 4 || order[3].String() != PluginName {
		t.Fatalf("analysis order override not applied: %v", order)
	}
	s := loadSettings()
	if s.URL != misp.URL || s.APIKey != "secret" {
		t.Fatalf("settings not loaded from pipeline YAML: %+v", s)
	}
	current.Store(s)
	refreshOnce(s)
	if db.Load().LookupIP("203.0.113.10") == nil {
		t.Fatal("refresh did not load indicators")
	}
	if _, err := os.Stat(s.CacheFile); err != nil {
		t.Fatalf("cache not written: %v", err)
	}

	// 2. serve the analysis plugin on its unix socket
	go func() { _ = plugins.InitAnalysisPlugin(PluginName, analyze) }()
	sock := filepath.Join(wd, "sockets", PluginName+"_analysis.sock")
	deadline := time.Now().Add(5 * time.Second)
	for {
		if _, err := os.Stat(sock); err == nil {
			break
		}
		if time.Now().After(deadline) {
			t.Fatalf("socket %s not created", sock)
		}
		time.Sleep(50 * time.Millisecond)
	}

	conn, err := grpc.NewClient("unix://"+sock, grpc.WithTransportCredentials(insecure.NewCredentials()),
		grpc.WithContextDialer(func(ctx context.Context, addr string) (net.Conn, error) {
			return (&net.Dialer{}).DialContext(ctx, "unix", sock)
		}))
	if err != nil {
		t.Fatal(err)
	}
	defer conn.Close()
	client := plugins.NewAnalysisClient(conn)

	call := func(ev *plugins.Event) ([]*plugins.Alert, error) {
		ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		defer cancel()
		stream, err := client.Analyze(ctx, ev)
		if err != nil {
			return nil, err
		}
		var out []*plugins.Alert
		for {
			a, err := stream.Recv()
			if errors.Is(err, io.EOF) {
				return out, nil
			}
			if err != nil {
				return out, err
			}
			out = append(out, a)
		}
	}

	alerts, err := call(&plugins.Event{Id: "1", DataType: "firewall-paloalto",
		Origin: &plugins.Side{Ip: "10.20.30.40"}, Target: &plugins.Side{Ip: "203.0.113.10"}})
	if err != nil || len(alerts) != 1 {
		t.Fatalf("expected 1 alert over gRPC, got %d (err %v)", len(alerts), err)
	}
	a := alerts[0]
	if a.Severity != "high" || a.Adversary.GetIp() != "203.0.113.10" || a.References[0] != misp.URL+"/events/view/42" {
		t.Fatalf("alert content wrong: %+v", a)
	}
	t.Logf("alert over gRPC: %s | %s | %s", a.Name, a.Severity, a.Description)

	// non-matching event: stream must end cleanly with io.EOF, no error
	alerts, err = call(&plugins.Event{Id: "2", Origin: &plugins.Side{Ip: "10.0.0.1"}, Target: &plugins.Side{Ip: "1.1.1.1"}})
	if err != nil || len(alerts) != 0 {
		t.Fatalf("non-matching event: alerts=%d err=%v", len(alerts), err)
	}
}

func write(t *testing.T, p, s string) {
	t.Helper()
	if err := os.WriteFile(p, []byte(s), 0o644); err != nil {
		t.Fatal(err)
	}
}
