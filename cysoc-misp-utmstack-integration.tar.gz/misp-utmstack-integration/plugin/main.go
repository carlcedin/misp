// com.utmstack.misp — UTMStack analysis plugin for MISP threat intelligence.
//
// It pulls IDS-flagged indicators (IPs, CIDRs, domains, URLs, hashes, emails)
// from a MISP instance on a schedule, keeps them in memory, checks every event
// the UTMStack EventProcessor analyses, and raises an alert on a match.
//
// Built for CySOC. Configuration lives in the EventProcessor pipeline folder:
//
//	/utmstack/events-engine-workdir/pipeline/cysoc_misp.yaml  (host)
//	/workdir/pipeline/cysoc_misp.yaml                          (container)
package main

import (
	"os"
	"time"

	"github.com/threatwinds/go-sdk/catcher"
	"github.com/threatwinds/go-sdk/plugins"
)

func main() {
	go refreshLoop()

	if err := plugins.InitAnalysisPlugin(PluginName, analyze); err != nil {
		_ = catcher.Error("failed to start analysis plugin", err, map[string]any{"process": processName})
		time.Sleep(5 * time.Second)
		os.Exit(1)
	}
}

func refreshLoop() {
	s := loadSettings()
	current.Store(s)

	// Warm start from the on-disk cache so detection is active immediately,
	// even if MISP is unreachable right now.
	if cached, err := loadCache(s.CacheFile); err == nil && cached.Size() > 0 {
		db.Store(cached)
		catcher.Info("loaded MISP indicators from cache", map[string]any{"process": processName, "counts": cached.Counts()})
	}

	for {
		s = loadSettings()
		current.Store(s)
		refreshOnce(s)
		pruneSuppression(time.Duration(s.SuppressMinutes) * time.Minute)
		time.Sleep(time.Duration(s.RefreshMinutes) * time.Minute)
	}
}

func refreshOnce(s *Settings) {
	start := time.Now()
	client, err := newMISPClient(s)
	if err != nil {
		_ = catcher.Error("MISP plugin is not configured", err, map[string]any{"process": processName})
		return
	}
	next, err := client.FetchIndicators()
	if err != nil {
		_ = catcher.Error("MISP refresh failed, keeping the previous indicator set", err, map[string]any{
			"process": processName, "url": s.URL,
		})
		return
	}
	if next.Size() == 0 && db.Load().Size() > 0 {
		catcher.Warn("MISP returned 0 indicators, keeping the previous set (check filters/lookback)", map[string]any{"process": processName})
		return
	}
	db.Store(next)
	saveCache(s.CacheFile, next)
	catcher.Info("MISP indicators refreshed", map[string]any{
		"process":          processName,
		"counts":           next.Counts(),
		"tookSeconds":      int(time.Since(start).Seconds()),
		"alertsSinceStart": matchCount.Load(),
	})
}
