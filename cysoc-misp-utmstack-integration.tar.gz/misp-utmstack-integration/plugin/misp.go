package main

import (
	"bytes"
	"crypto/tls"
	"crypto/x509"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"time"

	"github.com/threatwinds/go-sdk/catcher"
	"github.com/tidwall/gjson"
)

// mispClient talks to the MISP REST API with an auth key.
type mispClient struct {
	s    *Settings
	http *http.Client
}

func newMISPClient(s *Settings) (*mispClient, error) {
	if s.URL == "" || s.APIKey == "" {
		return nil, errors.New("MISP url and apiKey must be set in the plugin configuration")
	}
	tlsCfg := &tls.Config{MinVersion: tls.VersionTLS12, InsecureSkipVerify: s.InsecureSkipVerify} //nolint:gosec // opt-in for self-signed MISP
	if s.CACertFile != "" {
		pem, err := os.ReadFile(s.CACertFile)
		if err != nil {
			return nil, fmt.Errorf("cannot read caCertFile %s: %w", s.CACertFile, err)
		}
		pool, _ := x509.SystemCertPool()
		if pool == nil {
			pool = x509.NewCertPool()
		}
		if !pool.AppendCertsFromPEM(pem) {
			return nil, fmt.Errorf("caCertFile %s contains no PEM certificates", s.CACertFile)
		}
		tlsCfg.RootCAs = pool
	}
	return &mispClient{
		s: s,
		http: &http.Client{
			Timeout: time.Duration(s.TimeoutSeconds) * time.Second,
			Transport: &http.Transport{
				TLSClientConfig: tlsCfg,
				Proxy:           nil, // MISP is internal; never route it through an outbound proxy
			},
		},
	}, nil
}

func (c *mispClient) post(path string, body any) ([]byte, error) {
	b, _ := json.Marshal(body)
	req, err := http.NewRequest(http.MethodPost, c.s.URL+path, bytes.NewReader(b))
	if err != nil {
		return nil, err
	}
	req.Header.Set("Authorization", c.s.APIKey)
	req.Header.Set("Accept", "application/json")
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("User-Agent", "utmstack-misp-plugin/1.0")

	resp, err := c.http.Do(req)
	if err != nil {
		return nil, err
	}
	defer func() { _ = resp.Body.Close() }()

	data, err := io.ReadAll(io.LimitReader(resp.Body, 1<<30))
	if err != nil {
		return nil, err
	}
	if resp.StatusCode != http.StatusOK {
		msg := strings.TrimSpace(string(data))
		if len(msg) > 300 {
			msg = msg[:300]
		}
		return nil, fmt.Errorf("MISP %s returned HTTP %d: %s", path, resp.StatusCode, msg)
	}
	return data, nil
}

// FetchIndicators pulls attributes page by page and builds a new DB.
func (c *mispClient) FetchIndicators() (*DB, error) {
	s := c.s
	d := newDB()
	eventIDs := map[string]struct{}{}
	var all []*Indicator

	for page := 1; page <= s.MaxPages; page++ {
		q := map[string]any{
			"returnFormat":       "json",
			"type":               s.Types,
			"limit":              s.PageSize,
			"page":               page,
			"includeEventTags":   true,
			"enforceWarninglist": s.EnforceWarninglist,
			"deleted":            false,
		}
		if s.OnlyToIDS {
			q["to_ids"] = true
		}
		if s.PublishedOnly {
			q["published"] = true
		}
		if s.Lookback != "" && s.Lookback != "0" {
			q["last"] = s.Lookback
		}
		if len(s.Tags) > 0 {
			q["tags"] = s.Tags
		}

		data, err := c.post("/attributes/restSearch", q)
		if err != nil {
			return nil, err
		}
		attrs := gjson.GetBytes(data, "response.Attribute").Array()
		for _, a := range attrs {
			ind := &Indicator{
				Value:       a.Get("value").String(),
				Type:        a.Get("type").String(),
				Category:    a.Get("category").String(),
				Comment:     a.Get("comment").String(),
				EventID:     a.Get("event_id").String(),
				EventInfo:   a.Get("Event.info").String(),
				ThreatLevel: threatLevel(a.Get("Event.threat_level_id").String()),
			}
			for _, t := range a.Get("Tag.#.name").Array() {
				ind.Tags = append(ind.Tags, t.String())
			}
			if ind.Value == "" {
				continue
			}
			all = append(all, ind)
			if ind.ThreatLevel == "" && ind.EventID != "" {
				eventIDs[ind.EventID] = struct{}{}
			}
		}
		if len(attrs) < s.PageSize {
			break
		}
		if page == s.MaxPages {
			catcher.Warn("maxPages reached, indicator list truncated; raise maxPages or narrow lookback/types", map[string]any{
				"process": processName, "maxPages": s.MaxPages, "pageSize": s.PageSize,
			})
		}
	}

	// MISP's attribute search does not return the event threat level, so
	// resolve it from the event index (best effort; falls back to defaultSeverity).
	if s.UseThreatLevel && len(eventIDs) > 0 {
		levels, err := c.fetchThreatLevels(eventIDs)
		if err != nil {
			catcher.Warn("cannot read MISP event threat levels, using defaultSeverity", map[string]any{
				"process": processName, "error": err.Error(),
			})
		}
		for _, ind := range all {
			if ind.ThreatLevel == "" {
				ind.ThreatLevel = levels[ind.EventID]
			}
		}
	}

	for _, ind := range all {
		if _, skip := s.Allowlist[strings.ToLower(strings.TrimSpace(ind.Value))]; skip {
			continue
		}
		d.Add(ind)
	}
	return d, nil
}

// fetchThreatLevels returns eventID -> high|medium|low for the given events.
func (c *mispClient) fetchThreatLevels(ids map[string]struct{}) (map[string]string, error) {
	out := map[string]string{}
	list := make([]string, 0, len(ids))
	for id := range ids {
		list = append(list, id)
	}
	const batch = 500
	for i := 0; i < len(list); i += batch {
		end := i + batch
		if end > len(list) {
			end = len(list)
		}
		data, err := c.post("/events/index", map[string]any{
			"eventid": list[i:end],
			"limit":   batch,
			"page":    1,
		})
		if err != nil {
			return out, err
		}
		for _, e := range gjson.ParseBytes(data).Array() {
			ev := e
			if e.Get("Event").Exists() { // some MISP versions wrap each row
				ev = e.Get("Event")
			}
			if lvl := threatLevel(ev.Get("threat_level_id").String()); lvl != "" {
				out[ev.Get("id").String()] = lvl
			}
		}
	}
	return out, nil
}

// threatLevel maps MISP threat_level_id: 1 High, 2 Medium, 3 Low, 4 Undefined.
func threatLevel(id string) string {
	switch id {
	case "1":
		return "high"
	case "2":
		return "medium"
	case "3":
		return "low"
	}
	return ""
}

// ---- on-disk cache so detection survives a restart while MISP is unreachable ----

type cacheEntry struct {
	Table string     `json:"t"`
	Key   string     `json:"k"`
	Ind   *Indicator `json:"i"`
}

func saveCache(path string, d *DB) {
	if path == "" {
		return
	}
	list := make([]cacheEntry, 0, d.Size())
	for table, m := range map[string]map[string]*Indicator{
		"ip": d.IPs, "domain": d.Domains, "url": d.URLs, "hash": d.Hashes, "email": d.Emails,
	} {
		for k, v := range m {
			list = append(list, cacheEntry{Table: table, Key: k, Ind: v})
		}
	}
	for _, c := range d.CIDRs {
		list = append(list, cacheEntry{Table: "cidr", Key: c.Net.String(), Ind: c.Ind})
	}
	b, err := json.Marshal(list)
	if err != nil {
		return
	}
	if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
		return
	}
	tmp := path + ".tmp"
	if err := os.WriteFile(tmp, b, 0o600); err != nil {
		_ = catcher.Error("cannot write indicator cache", err, map[string]any{"process": processName, "file": path})
		return
	}
	_ = os.Rename(tmp, path)
}

func loadCache(path string) (*DB, error) {
	b, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	var list []cacheEntry
	if err := json.Unmarshal(b, &list); err != nil {
		return nil, err
	}
	d := newDB()
	for _, e := range list {
		if e.Ind == nil {
			continue
		}
		switch e.Table {
		case "ip":
			d.IPs[e.Key] = e.Ind
		case "cidr":
			if _, n, err := net.ParseCIDR(e.Key); err == nil {
				d.CIDRs = append(d.CIDRs, cidrIndicator{Net: n, Ind: e.Ind})
			}
		case "domain":
			d.Domains[e.Key] = e.Ind
		case "url":
			d.URLs[e.Key] = e.Ind
		case "hash":
			d.Hashes[e.Key] = e.Ind
		case "email":
			d.Emails[e.Key] = e.Ind
		}
	}
	return d, nil
}
