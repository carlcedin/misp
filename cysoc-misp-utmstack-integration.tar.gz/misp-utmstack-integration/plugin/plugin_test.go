package main

import (
	"encoding/json"
	"io"
	"net/http"
	"net/http/httptest"
	"path/filepath"
	"strings"
	"sync"
	"testing"

	"github.com/threatwinds/go-sdk/plugins"
	"github.com/tidwall/gjson"
	"google.golang.org/grpc"
)

// ---- mock MISP ----

type mockMISP struct {
	mu        sync.Mutex
	queries   []map[string]any
	authSeen  string
	pages     [][]map[string]any
	events    []map[string]any
	failAttrs bool
}

func (m *mockMISP) handler(w http.ResponseWriter, r *http.Request) {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.authSeen = r.Header.Get("Authorization")
	body, _ := io.ReadAll(r.Body)
	q := map[string]any{}
	_ = json.Unmarshal(body, &q)

	switch r.URL.Path {
	case "/attributes/restSearch":
		if m.failAttrs {
			http.Error(w, `{"message":"boom"}`, http.StatusInternalServerError)
			return
		}
		m.queries = append(m.queries, q)
		page := int(q["page"].(float64))
		var attrs []map[string]any
		if page-1 < len(m.pages) {
			attrs = m.pages[page-1]
		}
		_ = json.NewEncoder(w).Encode(map[string]any{"response": map[string]any{"Attribute": attrs}})
	case "/events/index":
		_ = json.NewEncoder(w).Encode(m.events)
	default:
		http.NotFound(w, r)
	}
}

func attr(typ, val, eventID string) map[string]any {
	return map[string]any{
		"type": typ, "value": val, "category": "Network activity", "event_id": eventID,
		"Event": map[string]any{"id": eventID, "info": "Campaign " + eventID},
		"Tag":   []map[string]any{{"name": "tlp:amber"}},
	}
}

func newTestSettings(url string) *Settings {
	s := defaults()
	s.URL, s.APIKey, s.InsecureSkipVerify = url, "test-key", true
	s.PageSize = 2
	s.CacheFile = ""
	s.SuppressMinutes = 0
	return s
}

func TestFetchIndicatorsPaginationThreatLevelAndAllowlist(t *testing.T) {
	m := &mockMISP{
		pages: [][]map[string]any{
			{attr("ip-dst", "203.0.113.10", "1"), attr("domain|ip", "evil.example|198.51.100.7", "2")},
			{attr("ip-dst", "192.0.2.0/24", "1"), attr("url", "HTTPS://Bad.Example/Payload/", "3")},
			{attr("filename|sha256", "a.exe|ABCDEF0123", "3"), attr("ip-src", "8.8.8.8", "1")},
			{},
		},
		events: []map[string]any{
			{"id": "1", "threat_level_id": "1"},
			{"Event": map[string]any{"id": "2", "threat_level_id": "3"}}, // wrapped form
		},
	}
	srv := httptest.NewTLSServer(http.HandlerFunc(m.handler))
	defer srv.Close()

	s := newTestSettings(srv.URL)
	s.Allowlist["8.8.8.8"] = struct{}{}
	c, err := newMISPClient(s)
	if err != nil {
		t.Fatal(err)
	}
	d, err := c.FetchIndicators()
	if err != nil {
		t.Fatal(err)
	}

	if m.authSeen != "test-key" {
		t.Fatalf("auth header not sent, got %q", m.authSeen)
	}
	if len(m.queries) != 4 {
		t.Fatalf("expected 4 page requests, got %d", len(m.queries))
	}
	q := m.queries[0]
	if q["to_ids"] != true || q["published"] != true || q["enforceWarninglist"] != true || q["last"] != "90d" {
		t.Fatalf("unexpected query filters: %v", q)
	}

	if ind := d.LookupIP("203.0.113.10"); ind == nil || ind.ThreatLevel != "high" {
		t.Fatalf("ip lookup/threat level wrong: %+v", ind)
	}
	if ind := d.LookupIP("198.51.100.7"); ind == nil || ind.ThreatLevel != "low" {
		t.Fatalf("domain|ip ip part not indexed or wrapped event level not parsed: %+v", ind)
	}
	if d.LookupDomain("evil.example", false) == nil {
		t.Fatal("domain|ip domain part not indexed")
	}
	if d.LookupIP("192.0.2.77") == nil {
		t.Fatal("CIDR indicator not matched")
	}
	if d.LookupURL("https://bad.example/Payload") == nil {
		t.Fatal("URL normalisation failed")
	}
	if ind := d.LookupHash("abcdef0123"); ind == nil || ind.ThreatLevel != "" {
		t.Fatalf("hash lookup wrong or unknown event got a level: %+v", ind)
	}
	if d.LookupIP("8.8.8.8") != nil {
		t.Fatal("allowlisted indicator should be skipped")
	}
}

func TestFetchFailureReturnsError(t *testing.T) {
	m := &mockMISP{failAttrs: true}
	srv := httptest.NewTLSServer(http.HandlerFunc(m.handler))
	defer srv.Close()
	c, _ := newMISPClient(newTestSettings(srv.URL))
	if _, err := c.FetchIndicators(); err == nil || !strings.Contains(err.Error(), "HTTP 500") {
		t.Fatalf("expected HTTP 500 error, got %v", err)
	}
}

func TestTLSVerificationEnforcedByDefault(t *testing.T) {
	m := &mockMISP{pages: [][]map[string]any{{}}}
	srv := httptest.NewTLSServer(http.HandlerFunc(m.handler))
	defer srv.Close()
	s := newTestSettings(srv.URL)
	s.InsecureSkipVerify = false
	c, _ := newMISPClient(s)
	if _, err := c.FetchIndicators(); err == nil {
		t.Fatal("self-signed certificate must be rejected unless insecureSkipVerify or caCertFile is set")
	}
}

func TestMissingConfig(t *testing.T) {
	if _, err := newMISPClient(defaults()); err == nil {
		t.Fatal("expected error when url/apiKey missing")
	}
}

// ---- matching and alerts ----

type fakeStream struct {
	grpc.ServerStream
	sent []*plugins.Alert
}

func (f *fakeStream) Send(a *plugins.Alert) error { f.sent = append(f.sent, a); return nil }

func loadTestDB(t *testing.T) {
	t.Helper()
	d := newDB()
	d.Add(&Indicator{Value: "203.0.113.10", Type: "ip-dst", EventID: "11", EventInfo: "C2 infra", ThreatLevel: "high", Tags: []string{"tlp:amber"}})
	d.Add(&Indicator{Value: "evil.example", Type: "domain", EventID: "12", ThreatLevel: "medium"})
	d.Add(&Indicator{Value: "44d88612fea8a8f36de82e1278abb02f", Type: "md5", EventID: "13", ThreatLevel: "low"})
	d.Add(&Indicator{Value: "phish@bad.example", Type: "email-src", EventID: "14"})
	db.Store(d)
}

func TestAnalyzeOutboundToMaliciousIP(t *testing.T) {
	loadTestDB(t)
	s := newTestSettings("https://10.210.17.244")
	current.Store(s)

	ev := &plugins.Event{
		Id: "e1", DataType: "firewall-fortigate-traffic", DataSource: "fw01", TenantId: "t1", TenantName: "CySOC",
		Origin: &plugins.Side{Ip: "10.1.1.5"},
		Target: &plugins.Side{Ip: "203.0.113.10", Port: 443},
	}
	fs := &fakeStream{}
	if err := analyze(ev, fs); err != nil {
		t.Fatal(err)
	}
	if len(fs.sent) != 1 {
		t.Fatalf("expected 1 alert, got %d", len(fs.sent))
	}
	a := fs.sent[0]
	if a.Severity != "high" || a.ImpactScore != 3 || a.Impact.Confidentiality != 3 {
		t.Fatalf("severity mapping wrong: %s %d", a.Severity, a.ImpactScore)
	}
	if a.Adversary.GetIp() != "203.0.113.10" || a.Target.GetIp() != "10.1.1.5" {
		t.Fatalf("adversary/target not swapped for target-side match: adv=%s tgt=%s", a.Adversary.GetIp(), a.Target.GetIp())
	}
	if a.Name != "MISP Threat Intelligence Match: Malicious IP" || a.Category != "Threat Intelligence" {
		t.Fatalf("unexpected name/category: %s / %s", a.Name, a.Category)
	}
	if len(a.References) != 1 || a.References[0] != "https://10.210.17.244/events/view/11" {
		t.Fatalf("reference wrong: %v", a.References)
	}
	if a.DataType != ev.DataType || a.TenantId != "t1" || a.Id == "" || a.Timestamp == "" {
		t.Fatal("alert metadata not copied")
	}
	if strings.Join(a.GroupBy, ",") != "lastEvent.log.mispIndicator,target.ip" || len(a.DeduplicateBy) != 0 {
		t.Fatalf("groupBy wrong: %v / %v", a.GroupBy, a.DeduplicateBy)
	}
	if got := a.Events[0].Log["mispIndicator"].GetStringValue(); got != "203.0.113.10" {
		t.Fatalf("event not enriched, mispIndicator=%q", got)
	}
	if ev.Log != nil {
		t.Fatal("original event must not be mutated")
	}
	// The alerts plugin resolves groupBy fields from the alert JSON; make sure they resolve.
	js, _ := json.Marshal(map[string]any{"events": []any{map[string]any{"log": map[string]any{"mispIndicator": "203.0.113.10"}}}})
	if gjson.GetBytes(js, "events.0.log.mispIndicator").String() != "203.0.113.10" {
		t.Fatal("groupBy path does not resolve")
	}
}

func TestAnalyzeSubdomainHashEmailAndNoMatch(t *testing.T) {
	loadTestDB(t)
	s := newTestSettings("https://misp")
	current.Store(s)

	cases := []struct {
		name string
		ev   *plugins.Event
		want string
		sev  string
	}{
		{"subdomain", &plugins.Event{Origin: &plugins.Side{Ip: "10.0.0.2"}, Target: &plugins.Side{Domain: "cdn.EVIL.example."}}, "Malicious Domain", "medium"},
		{"hash on origin", &plugins.Event{Origin: &plugins.Side{Md5: "44D88612FEA8A8F36DE82E1278ABB02F"}}, "Malicious File Hash", "low"},
		{"email default severity", &plugins.Event{Origin: &plugins.Side{EmailAddress: "Phish@Bad.Example"}}, "Malicious Email Address", "medium"},
		{"url host is listed domain", &plugins.Event{Target: &plugins.Side{Url: "https://www.evil.example:8443/x?y=1"}}, "Malicious Domain", "medium"},
		{"no match", &plugins.Event{Origin: &plugins.Side{Ip: "10.0.0.2"}, Target: &plugins.Side{Ip: "1.1.1.1", Domain: "example.com"}}, "", ""},
		{"bare tld never matches", &plugins.Event{Target: &plugins.Side{Domain: "example"}}, "", ""},
	}
	for _, c := range cases {
		fs := &fakeStream{}
		_ = analyze(c.ev, fs)
		if c.want == "" {
			if len(fs.sent) != 0 {
				t.Fatalf("%s: expected no alert", c.name)
			}
			continue
		}
		if len(fs.sent) != 1 || !strings.HasSuffix(fs.sent[0].Name, c.want) || fs.sent[0].Severity != c.sev {
			t.Fatalf("%s: got %+v", c.name, fs.sent)
		}
	}
}

func TestSubdomainMatchingCanBeDisabled(t *testing.T) {
	loadTestDB(t)
	s := newTestSettings("https://misp")
	s.MatchSubdomains = false
	current.Store(s)
	fs := &fakeStream{}
	_ = analyze(&plugins.Event{Target: &plugins.Side{Domain: "cdn.evil.example"}}, fs)
	if len(fs.sent) != 0 {
		t.Fatal("subdomain matched although matchSubdomains=false")
	}
}

func TestSuppressionMinSeverityAndDataTypeFilters(t *testing.T) {
	loadTestDB(t)
	s := newTestSettings("https://misp")
	s.SuppressMinutes = 60
	current.Store(s)
	ev := &plugins.Event{DataType: "fw", Origin: &plugins.Side{Ip: "10.9.9.9"}, Target: &plugins.Side{Ip: "203.0.113.10"}}
	fs := &fakeStream{}
	_ = analyze(ev, fs)
	_ = analyze(ev, fs)
	if len(fs.sent) != 1 {
		t.Fatalf("suppression failed, got %d alerts", len(fs.sent))
	}

	s2 := newTestSettings("https://misp")
	s2.MinSeverity = "medium"
	current.Store(s2)
	fs = &fakeStream{}
	_ = analyze(&plugins.Event{Origin: &plugins.Side{Md5: "44d88612fea8a8f36de82e1278abb02f"}}, fs)
	if len(fs.sent) != 0 {
		t.Fatal("low-severity alert should be dropped when minSeverity=medium")
	}

	s3 := newTestSettings("https://misp")
	s3.ExcludeTypes["noisy"] = struct{}{}
	current.Store(s3)
	fs = &fakeStream{}
	_ = analyze(&plugins.Event{DataType: "noisy", Target: &plugins.Side{Ip: "203.0.113.10"}}, fs)
	if len(fs.sent) != 0 {
		t.Fatal("excluded dataType should not alert")
	}
}

func TestExtraLogFieldsAndAlertModes(t *testing.T) {
	loadTestDB(t)
	s := newTestSettings("https://misp")
	s.ExtraFields = []string{"log.dns.query"}
	s.AlertMode = "deduplicate"
	current.Store(s)

	var ev plugins.Event
	raw := `{"dataType":"dns","log":{"dns":{"query":"login.evil.example"}}}`
	if err := protojsonUnmarshal(raw, &ev); err != nil {
		t.Fatal(err)
	}
	fs := &fakeStream{}
	_ = analyze(&ev, fs)
	if len(fs.sent) != 1 || fs.sent[0].Events[0].Log["mispMatchedField"].GetStringValue() != "log.dns.query" {
		t.Fatalf("extra field match failed: %+v", fs.sent)
	}
	if len(fs.sent[0].DeduplicateBy) == 0 || len(fs.sent[0].GroupBy) != 0 {
		t.Fatal("deduplicate mode not applied")
	}
}

func TestParseSettings(t *testing.T) {
	cfg := gjson.Parse(`{"url":"https://10.210.17.244/","apiKey":" k ","insecureSkipVerify":true,
	 "refreshMinutes":5,"lookback":"30d","onlyToIds":false,"types":["ip-dst"],"minSeverity":"HIGH",
	 "allowlist":["8.8.8.8"],"alertMode":"none","suppressMinutes":0,"pageSize":10}`)
	s := parseSettings(cfg)
	if s.URL != "https://10.210.17.244" || s.APIKey != "k" || !s.InsecureSkipVerify || s.RefreshMinutes != 5 ||
		s.Lookback != "30d" || s.OnlyToIDS || len(s.Types) != 1 || s.MinSeverity != "high" ||
		s.AlertMode != "none" || s.SuppressMinutes != 0 || s.PageSize != 5000 {
		t.Fatalf("settings parsed wrong: %+v", s)
	}
	if _, ok := s.Allowlist["8.8.8.8"]; !ok {
		t.Fatal("allowlist not parsed")
	}
	if d := parseSettings(gjson.Result{}); d.RefreshMinutes != 15 || !d.PublishedOnly {
		t.Fatal("defaults wrong")
	}
}

func TestCacheRoundTrip(t *testing.T) {
	d := newDB()
	d.Add(&Indicator{Value: "domain.example|198.51.100.1", Type: "domain|ip", EventID: "5", ThreatLevel: "high"})
	d.Add(&Indicator{Value: "192.0.2.0/25", Type: "ip-dst"})
	d.Add(&Indicator{Value: "http://x.example/a", Type: "url"})
	p := filepath.Join(t.TempDir(), "cache.json")
	saveCache(p, d)
	got, err := loadCache(p)
	if err != nil {
		t.Fatal(err)
	}
	if got.Size() != d.Size() {
		t.Fatalf("size %d != %d", got.Size(), d.Size())
	}
	if ind := got.LookupIP("198.51.100.1"); ind == nil || ind.Type != "domain|ip" || ind.ThreatLevel != "high" {
		t.Fatalf("original type/level lost: %+v", ind)
	}
	if got.LookupIP("192.0.2.100") == nil || got.LookupURL("https://X.example/a/") == nil {
		t.Fatal("cidr/url lost in cache")
	}
}
