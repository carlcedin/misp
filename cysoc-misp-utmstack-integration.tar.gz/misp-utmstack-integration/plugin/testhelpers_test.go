package main

import (
	"google.golang.org/protobuf/encoding/protojson"
	"google.golang.org/protobuf/proto"
)

func protojsonUnmarshal(s string, m proto.Message) error {
	return protojson.Unmarshal([]byte(s), m)
}
